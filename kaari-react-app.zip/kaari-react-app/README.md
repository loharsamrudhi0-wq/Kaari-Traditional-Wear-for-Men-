# Kaari — Tradition Reimagined
### Heritage Men's Ethnic Wear (React SPA)

**Brand:** कारि • TRADITION REIMAGINED

## How to Run

1. Open `index.html` directly in any modern browser  
   **or**
2. Serve locally:
   ```bash
   # Python
   python3 -m http.server 8080

   # Node
   npx serve .
   ```
3. Visit `http://localhost:8080`

## Features

- Sticky navigation with Royal Bag counter
- Hero banner with Sanskrit subtitle
- Shop with category filters (16 products)
- Product detail view with size selector
- Customization Studio (12 archival swatches + saree upload)
- Heritage Craft story & gallery
- Cart drawer + Checkout gateway (UPI / Card / COD)
- Order confirmation screen

## Tech

- React 18 (CDN)
- Tailwind CSS (CDN)
- Babel Standalone
- Font Awesome 6
- Google Fonts: Cinzel, Cormorant Garamond, Inknut Antiqua

## Colour Palette

| Token            | Hex       |
|------------------|-----------|
| Parchment        | `#FDFBF7` |
| Parchment Dark   | `#FAF6EE` |
| Royal Gold       | `#D4AF37` |
| Deep Emerald     | `#0B3024` |
| Royal Maroon     | `#58181F` |
| Dark Bronze      | `#2C221E` |
| Warm Charcoal    | `#1C1917` |

---
© 2026 Kaari. Crafted with reverence in India.
